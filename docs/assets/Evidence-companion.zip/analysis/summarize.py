"""Rebuild the paper counts from the companion extraction (Python standard library)."""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
USES = {
    "representation": "Predictive representation",
    "train": "Policy training",
    "plan": "Planning and selection",
    "generate": "Action generation",
    "assess": "Assessment",
    "execute": "Execution and intervention",
}

def summarize(rows):
    groups = [("Any use", rows)] + [
        (label, [r for r in rows if r["use"] == use])
        for use, label in USES.items()
    ]
    result = []
    for label, group in groups:
        observed = [r for r in group if r["access"] == "direct" and r["downstream"] == "yes"]
        compared = [r for r in observed if r["within_study"] == "yes"]
        attributable = [r for r in compared if r["specific"] == "yes"]
        counts = [len({r["key"] for r in subset}) for subset in (group, observed, compared, attributable)]
        result.append(dict(zip(("use", "screened", "downstream", "compared", "specific"), (label, *counts))))
    return result

if __name__ == "__main__":
    with (ROOT / "comparisons.csv").open(newline="") as source:
        rows = list(csv.DictReader(source))
    for row in rows:
        assert row["use"] in USES, row
        assert row["access"] in {"direct", "inherited"}, row
        assert all(row[k] in {"yes","no"} for k in ("downstream","within_study","specific")), row
        if row["specific"] == "yes":
            assert row["downstream"] == row["within_study"] == "yes", row
        assert row["locator"] and row["result"] and row["comparison"], row
    result = summarize(rows)
    assert result[0]["screened"] == 75
    with (ROOT / "summary.csv").open("w", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=result[0])
        writer.writeheader()
        writer.writerows(result)
